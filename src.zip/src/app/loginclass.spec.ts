import { Loginclass } from './loginclass';

describe('Loginclass', () => {
  it('should create an instance', () => {
    expect(new Loginclass()).toBeTruthy();
  });
});
