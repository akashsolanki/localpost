import { Signup } from './signup';

describe('Signup', () => {
  it('should create an instance', () => {
    expect(new Signup()).toBeTruthy();
  });
});
