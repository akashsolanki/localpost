export class Signup {
    email: string;
    password: string;
}
